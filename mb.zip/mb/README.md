Important notes for Class 3

## Models
After we finish out models in the python file, we need to run these commands:
- makemigrations -> Translation from the models.py into the sql part 
- migrate -> It's going to apply the migrations file into the db  